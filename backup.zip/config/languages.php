<?php
    return [
        'supported' => [
            'vi'=>[
                'value'=>'vi',
                'name'=>'Việt Nam',
                'image'=>'',
            ],
            // 'en'=>[
            //     'value'=>'en',
            //     'name'=>'English',
            //     'image'=>'',
            // ],
            // 'ko'=>[
            //     'value'=>'ko',
            //     'name'=>'Korea',
            //     'image'=>'',
            // ],
        ],
        'default'=>'vi',
    ];
?>
