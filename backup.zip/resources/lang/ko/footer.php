<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Home Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'gui_yeu_cau_tu_van' => '상담 요청 보내기',
    'ho_ten' => '성명',
    'email' => '이메일',
    'so_dien_thoai' => '전화 번호',

];
