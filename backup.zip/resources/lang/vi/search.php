<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Home Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'ket_qua_tim_kiem_san_pham' => 'Kết quả tìm kiếm sản phẩm ',
    'ket_qua_tim_kiem_tin_tuc' => 'Kết quả tìm kiếm tin tức',
];
